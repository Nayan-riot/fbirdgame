import pygame
import asyncio
import random

pygame.init()

red = (200, 0, 0)
black = (0, 0, 0)
white = (233, 233, 233)

gamewidth = 400
gameheight = 600

gamewindow = pygame.display.set_mode((gamewidth, gameheight))
pygame.display.set_caption("Flappy Bird")

clock = pygame.time.Clock()

bgimg = pygame.image.load("flappybirdbg.png")
bgimg = pygame.transform.scale(
    bgimg, (gamewidth, gameheight)
).convert_alpha()

fbird = pygame.image.load("fbirdtrans.png")
fbird = pygame.transform.scale(
    fbird, (50, 50)
).convert_alpha()

fbirdwelcome = pygame.image.load("fbirdfrontpage.png")
fbirdwelcome = pygame.transform.scale(
    fbirdwelcome, (gamewidth, gameheight)
).convert_alpha()

fobs = pygame.image.load("flapppyobstrans.png")
fobs = pygame.transform.scale(fobs, (70, 520)).convert_alpha()

fobs2 = pygame.image.load("flapppyobstrans.png")
fobs2 = pygame.transform.scale(fobs2, (70, 519))
fobs2 = pygame.transform.flip(fobs2, False, True).convert_alpha()


def score_scr(text, color, f, x, y):
    font = pygame.font.SysFont(None, f)
    screen_text = font.render(text, True, color)
    gamewindow.blit(screen_text, (x, y))


async def welcome():
    while True:
        gamewindow.blit(fbirdwelcome, (0, 0))

        score_scr("Developer:-", black, 30, 170, 520)
        score_scr("Nayan Adhikari", (100, 0, 0), 30, 147, 550)
        score_scr("Press ENTER to play", white, 25, 90, 450)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    return True

        pygame.display.update()
        clock.tick(60)
        await asyncio.sleep(0)


async def gameloop():
    bird_x = 130
    bird_y = 100
    bird_velocity_y = 0

    obstacle_x = 400
    obstacle_y = 300

    obstacle1_x = 650
    obstacle1_y = 280

    obstacle_velocity_x = 2
    gravity = 0.15
    jump_strength = -4

    game_score = 0
    scored_obstacles = set()
    game_over = False

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False

            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_UP, pygame.K_SPACE):
                    if not game_over:
                        bird_velocity_y = jump_strength
                    else:
                        return True

        if not game_over:
            bird_velocity_y += gravity
            bird_y += bird_velocity_y

            obstacle_x -= obstacle_velocity_x
            obstacle1_x -= obstacle_velocity_x

            if obstacle_x < -70:
                obstacle_x = gamewidth
                obstacle_y = random.choice([250, 280, 300, 330])
                scored_obstacles.discard(0)

            if obstacle1_x < -70:
                obstacle1_x = gamewidth
                obstacle1_y = random.choice([250, 280, 320, 350])
                scored_obstacles.discard(1)

            # Draw the background
            gamewindow.blit(bgimg, (0, 0))

            # Draw lower obstacles
            gamewindow.blit(
                fobs, (obstacle_x - 8, obstacle_y - 9)
            )
            gamewindow.blit(
                fobs, (obstacle1_x - 8, obstacle1_y - 9)
            )

            # Draw upper obstacles
            gamewindow.blit(
                fobs2, (obstacle_x - 8, obstacle_y - 650)
            )
            gamewindow.blit(
                fobs2, (obstacle1_x - 8, obstacle1_y - 650)
            )

            # Ground
            pygame.draw.rect(
                gamewindow, black, (0, 440, gamewidth, 160)
            )

            # Bird collision rectangle
            bird_rect = pygame.Rect(bird_x, bird_y, 30, 30)

            # Obstacle collision rectangles
            obstacles = [
                pygame.Rect(obstacle_x, obstacle_y, 50, 700),
                pygame.Rect(obstacle1_x, obstacle1_y, 50, 700),
                pygame.Rect(obstacle_x, obstacle_y - 650, 50, 500),
                pygame.Rect(obstacle1_x, obstacle1_y - 650, 50, 500),
            ]

            # Check collisions
            if bird_y < 0 or bird_y + 30 >= 440:
                game_over = True

            for obstacle in obstacles:
                if bird_rect.colliderect(obstacle):
                    game_over = True

            # Award score once per obstacle pair
            if obstacle_x + 50 < bird_x and 0 not in scored_obstacles:
                game_score += 10
                scored_obstacles.add(0)

            if obstacle1_x + 50 < bird_x and 1 not in scored_obstacles:
                game_score += 10
                scored_obstacles.add(1)

            # Draw bird and score
            gamewindow.blit(fbird, (bird_x - 10, bird_y - 10))
            score_scr(
                f"Score = {game_score}", white, 30, 50, 500
            )

        else:
            gamewindow.fill(black)
            score_scr("Game Over!", red, 40, 115, 200)
            score_scr("Press SPACE to restart", white, 25, 65, 260)
            score_scr(
                f"Final Score: {game_score}", white, 30, 100, 320
            )

        pygame.display.update()
        clock.tick(50)
        await asyncio.sleep(0)


async def main():
    running = True

    while running:
        running = await welcome()

        if running:
            running = await gameloop()

    pygame.quit()


asyncio.run(main())